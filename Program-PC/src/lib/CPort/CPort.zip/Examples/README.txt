Examples for the Comport Library
================================

Please note, that these examples haven't been updated
for a long time, they might not be up to date.

If you update any of these to newer Delphi versions,
or improve on them, please send me a copy of them to
Lars@dybdahl.dk or warren.postma@gmail.com

